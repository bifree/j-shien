<ul class="page-lists _flex">
    <li class="page-lists__item">
        <a href="/campaign_manga current-page">会社設立後のお助け隊とは</a>
    </li>
    <li class="page-lists__item">
        <a href="/campaign_flow">選ばれる理由</a>
    </li>
    <li class="page-lists__item">
        <a href="/campaign_flow">会社設立後の届出書類</a>
    </li>
    <li class="page-lists__item">
        <a href="/campaign_flow">税理士とは</a>
    </li>
</ul>