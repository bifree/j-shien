<div class="apply-block">
	<div class="apply-block-inner">
		<h4>設立３カ月以内の法人様限定</h4><h3>面倒な手続きを税理士にお任せ！</h3>
		<img src="https://todokede.sakura.ne.jp/ne2/wp-content/uploads/2021/12/offer_btn.png" alt="">
		<div class="free-dial">
			<div class="left">
				<div class="inner">
					<p class="bigger">設立後の無料相談ダイヤルはこちら</p>
					<p class="smaller">（携帯電話からもご利用いただけます）</p>
				</div>
			</div>
			<div class="right">
				<p class="bigger">0120-955-761</p>
				<p>受付時間：10:00〜16:30（平日）</p>
			</div>
		</div>
		<p>※電子申請キャンペーンは１担当者様１度限りです。<br class="sp-br">複数の会社の同時申込もできません。</p>
	</div>
</div>