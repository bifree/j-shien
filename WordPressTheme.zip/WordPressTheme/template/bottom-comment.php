<section class="comments">
    <div class="inner">
        <h2 class="comments-title">会社設立後の疑問と手間を解消</h2>
        <p class="comments-text">
            会社設立後の官公庁への面倒な手続きを
            <br><span>税理士</span>が<span>無料</span>で<span>電子申請</span>します！<span></span>
        </p>
    </div>
</section>