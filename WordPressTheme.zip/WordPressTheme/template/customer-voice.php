<div class="top-customer-voice">
	<p class="title">VOICE</p>
	<h3>お客様の声</h3>
	<div class="wrapper">
		<div class="voice-box">
			<img src="" alt="">
			<div class="name">
				<p></p>
				<p></p>
			</div>
			<div class="text">
				
			</div>
		</div>
	</div>
	<div class="btn">
		<a href="">会社設立後の届出書類の詳細はこちら</a>
	</div>
</div>